package com.jeevan.TradingApp.response;

import lombok.Data;

@Data
public class ApiResponse {
    private String message;
}
