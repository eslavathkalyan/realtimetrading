package com.jeevan.TradingApp.domain;

public enum PaymentMethod {
    RAZORPAY , STRIPE
}
