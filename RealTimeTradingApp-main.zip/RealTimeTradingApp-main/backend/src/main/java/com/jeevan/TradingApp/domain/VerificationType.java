package com.jeevan.TradingApp.domain;

public enum VerificationType {
    MOBILE , EMAIL
}
