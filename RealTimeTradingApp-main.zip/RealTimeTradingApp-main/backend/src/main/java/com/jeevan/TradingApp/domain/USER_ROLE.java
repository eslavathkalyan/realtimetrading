package com.jeevan.TradingApp.domain;

public enum USER_ROLE {
    ROLE_ADMIN, ROLE_CUSTOMER
}
