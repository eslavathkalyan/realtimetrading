package com.jeevan.TradingApp.domain;

public enum WithdrawalStatus {
    PENDING , SUCCESS , DECLINE;
}
