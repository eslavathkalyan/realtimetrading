package com.jeevan.TradingApp.config;

public class JwtConstant {
    public static final String secret_key = "kkkkkkkkkkakfladfjlajdlfjalkfjlskjfslfjlkfjldfjaleoiorklekrek";
    public static final String jwt_header = "Authorization";
}
