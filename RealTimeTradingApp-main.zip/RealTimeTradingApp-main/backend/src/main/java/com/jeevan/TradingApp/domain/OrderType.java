package com.jeevan.TradingApp.domain;

public enum OrderType {
    BUY, SELL
}
