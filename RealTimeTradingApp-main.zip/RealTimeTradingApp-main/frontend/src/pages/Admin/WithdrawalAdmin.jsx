import React from 'react'

function WithdrawalAdmin() {
    return (
        <div>
            
        </div>
    )
}

export default WithdrawalAdmin
